import 'package:flutter/material.dart';
import 'database_helper.dart';

class StatesProvider with ChangeNotifier {
  List<Map<String, dynamic>> _states = [];
  final DatabaseHelper _dbHelper = DatabaseHelper();

  List<Map<String, dynamic>> get states => _states;

  StatesProvider() {
    _fetchStates();
  }

  Future<void> _fetchStates() async {
    final data = await _dbHelper.getStates();
    _states = data;
    notifyListeners();
  }

  Future<void> addState(String name) async {
    await _dbHelper.insertState(name);
    await _fetchStates();
  }

  Future<void> deleteState(int id) async {
    await _dbHelper.deleteState(id);
    await _fetchStates();
  }

  Future<void> updateStatePosition(int id, int position) async {
    await _dbHelper.updateStatePosition(id, position);
    await _fetchStates();
  }
}
