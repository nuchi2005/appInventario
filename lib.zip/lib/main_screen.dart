import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:barcode_scan2/barcode_scan2.dart';
import 'package:provider/provider.dart';
import 'listaEquipo.dart';
import 'admin_states_screen.dart';
import 'admin_types_screen.dart';
import 'admin_notifications_screen.dart';
import 'types_provider.dart';
import 'states_provider.dart';
import 'equipments_provider.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _currentIndex = 0;

  void onTabTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
    if (index == 1) {
      final equipmentsProvider = context.read<EquipmentsProvider>();
      equipmentsProvider.fetchEquipments();
    }
  }

  void switchToListScreen() {
    setState(() {
      _currentIndex = 1;
    });
    final equipmentsProvider = context.read<EquipmentsProvider>();
    equipmentsProvider.fetchEquipments();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Inventario SHELA'),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            const DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.blue,
              ),
              child: Text(
                'Menú',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                ),
              ),
            ),
            ListTile(
              leading: Icon(Icons.settings),
              title: Text('Administrar Estados'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => AdminStatesScreen()),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.category),
              title: Text('Administrar Tipos'),
              onTap: () async {
                await Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => AdminTypesScreen()),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.notifications),
              title: Text('Administrar Notificaciones'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => AdminNotificationsScreen()),
                );
              },
            ),
          ],
        ),
      ),
      body: IndexedStack(
        index: _currentIndex,
        children: [
          MainScreenContent(onSave: switchToListScreen),
          ListScreen(),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: onTabTapped,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.list),
            label: 'Lista de Equipos',
          ),
        ],
      ),
    );
  }
}

class MainScreenContent extends StatefulWidget {
  final VoidCallback onSave;

  MainScreenContent({required this.onSave});

  @override
  _MainScreenContentState createState() => _MainScreenContentState();
}

class _MainScreenContentState extends State<MainScreenContent> {
  final _orderNumberController = TextEditingController();
  final _initialFaultController = TextEditingController();
  final _technicalObservationController = TextEditingController();

  String _selectedType = 'TV Led';
  String _seen = 'No';
  String _selectedStatus = 'Ingreso nuevo';
  DateTime? _selectedDate;

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate ?? DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
      locale: const Locale('es', 'ES'),
    );
    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }

  Future<void> _scanBarcode() async {
    var result = await BarcodeScanner.scan();
    setState(() {
      _orderNumberController.text = result.rawContent;
    });
  }

  Future<void> _saveEquipment() async {
    final equipmentsProvider =
        Provider.of<EquipmentsProvider>(context, listen: false);

    if (await equipmentsProvider
        .orderNumberExists(_orderNumberController.text)) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('El número de orden ya existe')),
      );
      return;
    }

    final creationDate = DateTime.now();
    await equipmentsProvider.addEquipment({
      'orderNumber': _orderNumberController.text,
      'type': _selectedType,
      'initialFault': _initialFaultController.text,
      'technicalObservation': _technicalObservationController.text,
      'seen': _seen == 'Sí' ? 'true' : 'false',
      'status': _selectedStatus,
      'creationDate': DateFormat('yyyy-MM-dd').format(creationDate),
      'deliveryDate': _selectedDate != null
          ? DateFormat('yyyy-MM-dd').format(_selectedDate!)
          : '',
    });
    _resetFields();
    await equipmentsProvider.fetchEquipments();
    widget.onSave(); // Cambiar a la pestaña de lista de equipos
  }

  void _resetFields() {
    setState(() {
      _orderNumberController.clear();
      _initialFaultController.clear();
      _technicalObservationController.clear();
      final typesProvider = context.read<TypesProvider>();
      if (typesProvider.types.isNotEmpty) {
        _selectedType = typesProvider.types[0]['name'];
      } else {
        _selectedType = 'TV Led';
      }
      _seen = 'No';
      final statesProvider = context.read<StatesProvider>();
      if (statesProvider.states.isNotEmpty) {
        _selectedStatus = statesProvider.states[0]['name'];
      } else {
        _selectedStatus = 'Ingreso nuevo';
      }
      _selectedDate = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Consumer2<TypesProvider, StatesProvider>(
      builder: (context, typesProvider, statesProvider, child) {
        if (typesProvider.types.isNotEmpty &&
            !_selectedType.contains(typesProvider.types[0]['name'])) {
          _selectedType = typesProvider.types[0]['name'];
        }

        if (statesProvider.states.isNotEmpty &&
            !_selectedStatus.contains(statesProvider.states[0]['name'])) {
          _selectedStatus = statesProvider.states[0]['name'];
        }

        return SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _orderNumberController,
                      decoration: const InputDecoration(
                        labelText: 'Numero de Orden',
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ),
                  IconButton(
                    icon: Icon(Icons.camera_alt),
                    onPressed: _scanBarcode,
                  ),
                ],
              ),
              SizedBox(height: 16.0),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 12.0, vertical: 4.0),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey),
                  borderRadius: BorderRadius.circular(5.0),
                ),
                child: DropdownButton<String>(
                  isExpanded: true,
                  value: _selectedType,
                  onChanged: (String? newValue) {
                    setState(() {
                      _selectedType = newValue!;
                    });
                  },
                  items:
                      typesProvider.types.map<DropdownMenuItem<String>>((type) {
                    return DropdownMenuItem<String>(
                      value: type['name'],
                      child: Text(type['name']),
                    );
                  }).toList(),
                  underline: SizedBox(),
                ),
              ),
              SizedBox(height: 16.0),
              TextField(
                controller: _initialFaultController,
                decoration: const InputDecoration(
                  labelText: 'Falla Inicial',
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 16.0),
              TextField(
                controller: _technicalObservationController,
                decoration: const InputDecoration(
                  labelText: 'Observacion tecnica',
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 16.0),
              Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'Visto',
                  style: TextStyle(fontSize: 16.0, color: Colors.black54),
                ),
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 12.0, vertical: 4.0),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey),
                  borderRadius: BorderRadius.circular(5.0),
                ),
                child: DropdownButton<String>(
                  isExpanded: true,
                  value: _seen,
                  onChanged: (String? newValue) {
                    setState(() {
                      _seen = newValue!;
                    });
                  },
                  items: <String>['Sí', 'No']
                      .map<DropdownMenuItem<String>>((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(value),
                    );
                  }).toList(),
                  underline: SizedBox(),
                ),
              ),
              SizedBox(height: 16.0),
              Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'Estado',
                  style: TextStyle(fontSize: 16.0, color: Colors.black54),
                ),
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 12.0, vertical: 4.0),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey),
                  borderRadius: BorderRadius.circular(5.0),
                ),
                child: DropdownButton<String>(
                  isExpanded: true,
                  value: _selectedStatus,
                  onChanged: (String? newValue) {
                    setState(() {
                      _selectedStatus = newValue!;
                    });
                  },
                  items: statesProvider.states
                      .map<DropdownMenuItem<String>>((state) {
                    return DropdownMenuItem<String>(
                      value: state['name'],
                      child: Text(state['name']),
                    );
                  }).toList(),
                  underline: SizedBox(),
                ),
              ),
              SizedBox(height: 16.0),
              GestureDetector(
                onTap: () => _selectDate(context),
                child: AbsorbPointer(
                  child: TextField(
                    decoration: InputDecoration(
                      labelText: 'Fecha de Entrega',
                      hintText: _selectedDate == null
                          ? 'No seleccionada'
                          : DateFormat('dd/MM/yyyy').format(_selectedDate!),
                      border: OutlineInputBorder(),
                      suffixIcon: Icon(Icons.calendar_today),
                    ),
                  ),
                ),
              ),
              if (_selectedDate != null)
                Padding(
                  padding: const EdgeInsets.only(top: 8.0),
                  child: Text(
                    'Fecha seleccionada: ${DateFormat('dd/MM/yyyy').format(_selectedDate!)}',
                    style: TextStyle(fontSize: 16.0, color: Colors.black54),
                  ),
                ),
              SizedBox(height: 16.0),
              ElevatedButton(
                onPressed: _saveEquipment,
                child: const Text('Guardar'),
              ),
            ],
          ),
        );
      },
    );
  }
}
