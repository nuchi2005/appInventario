import 'package:flutter/material.dart';

class AdminNotificationsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Administrar Notificaciones'),
      ),
      body: Center(
        child: Text('Pantalla para administrar notificaciones'),
      ),
    );
  }
}
