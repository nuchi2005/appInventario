import 'package:flutter/material.dart';
import 'database_helper.dart';

class TypesProvider with ChangeNotifier {
  List<Map<String, dynamic>> _types = [];
  final DatabaseHelper _dbHelper = DatabaseHelper();

  List<Map<String, dynamic>> get types => _types;

  TypesProvider() {
    _fetchTypes();
  }

  Future<void> _fetchTypes() async {
    final data = await _dbHelper.getTypes();
    _types = data;
    notifyListeners();
  }

  Future<void> addType(String name) async {
    await _dbHelper.insertType(name);
    await _fetchTypes();
  }

  Future<void> deleteType(int id) async {
    await _dbHelper.deleteType(id);
    await _fetchTypes();
  }

  Future<void> updateTypePosition(int id, int position) async {
    await _dbHelper.updateTypePosition(id, position);
    await _fetchTypes();
  }
}
